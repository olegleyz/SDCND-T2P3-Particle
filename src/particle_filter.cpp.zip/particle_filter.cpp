/*
 * particle_filter.cpp
 *
 *  Created on: Dec 12, 2016
 *      Author: Tiffany Huang
 */

#include <random>
#include <algorithm>
#include <iostream>
#include <numeric>
#include <map>

#include "particle_filter.h"
#include "helper_functions.h"

using namespace std;

void ParticleFilter::init(double x, double y, double theta, double std[]) {
	// TODO: Set the number of particles. Initialize all particles to first position (based on estimates of 
	//   x, y, theta and their uncertainties from GPS) and all weights to 1. 
	// Add random Gaussian noise to each particle.
	// NOTE: Consult particle_filter.h for more information about this method (and others in this file).
	num_particles = 5;

    // noise generation
    default_random_engine gen;// random number engine class that generates pseudo-random numbers
    normal_distribution<double> dist_x(x, std[0]);
    normal_distribution<double> dist_y(y, std[1]);
    normal_distribution<double> dist_theta(theta, std[2]);

    for (int i = 0; i < num_particles; i++) {
        // initialize num_particles particles

        Particle particle;
        particle.id = i;
        particle.x = dist_x(gen);
        particle.y = dist_y(gen);
        particle.theta = dist_theta(gen);
        particle.weight = 1.0;
        particles.push_back(particle);
        weights.push_back(particle.weight);
    }
    is_initialized = true;


 }

void ParticleFilter::prediction(double delta_t, double std_pos[], double velocity, double yaw_rate) {
	// TODO: Add measurements to each particle and add random Gaussian noise.
	// NOTE: When adding noise you may find std::normal_distribution and std::default_random_engine useful.
	//  http://en.cppreference.com/w/cpp/numeric/random/normal_distribution
	//  http://www.cplusplus.com/reference/random/default_random_engine/

    //random_device rd;
    //default_random_engine gen(rd());// random number engine class that generates pseudo-random numbers
    default_random_engine gen;// random number engine class that generates pseudo-random numbers
    normal_distribution<double> noise_x(0, std_pos[0]);
    normal_distribution<double> noise_y(0, std_pos[1]);
    normal_distribution<double> noise_theta(0, std_pos[2]);

    double v_dev_yawd, v_dt, yaw_rate_dt;;
    if (fabs(yaw_rate) > 0.001) {
        v_dev_yawd = velocity / yaw_rate;
        yaw_rate_dt = yaw_rate * delta_t;
    } else {
        v_dt = velocity * delta_t;
    };

    for (int i = 0; i<particles.size(); i++) {

        if (fabs(yaw_rate) > 0.001) {
            double heading_new = particles[i].theta + yaw_rate_dt;// + noise_theta(gen);
            particles[i].x += v_dev_yawd * (sin(heading_new) - sin(particles[i].theta));// + noise_x(gen);
            particles[i].y += v_dev_yawd * (cos(particles[i].theta) - cos(heading_new));// + noise_y(gen);
            particles[i].theta = heading_new;
        } else {
            particles[i].x += v_dt * cos(particles[i].theta);
            particles[i].y += v_dt * sin(particles[i].theta);
        }

        normal_distribution<double> pos_error_x(particles[i].x, std_pos[0]);
        normal_distribution<double> pos_error_y(particles[i].y, std_pos[1]);
        normal_distribution<double> pos_error_theta(particles[i].theta, std_pos[2]);

        particles[i].x = pos_error_x(gen);
        particles[i].y = pos_error_y(gen);
        particles[i].theta = pos_error_theta(gen);

    }
}

void ParticleFilter::dataAssociation(std::vector<LandmarkObs> predicted, std::vector<LandmarkObs>& observations) {
	// TODO: Find the predicted measurement that is closest to each observed measurement and assign the 
	//   observed measurement to this particular landmark.
	// NOTE: this method will NOT be called by the grading code. But you will probably find it useful to 
	//   implement this method and use it as a helper during the updateWeights phase.


}

void ParticleFilter::updateWeights(double sensor_range, double std_landmark[], 
		std::vector<LandmarkObs> observations, Map map_landmarks) {
	// TODO: Update the weights of each particle using a mult-variate Gaussian distribution. You can read
	//   more about this distribution here: https://en.wikipedia.org/wiki/Multivariate_normal_distribution
	// NOTE: The observations are given in the VEHICLE'S coordinate system. Your particles are located
	//   according to the MAP'S coordinate system. You will need to transform between the two systems.
	//   Keep in mind that this transformation requires both rotation AND translation (but no scaling).
	//   The following is a good resource for the theory:
	//   https://www.willamette.edu/~gorr/classes/GeneralGraphics/Transforms/transforms2d.htm
	//   and the following is a good resource for the actual equation to implement (look at equation 
	//   3.33. Note that you'll need to switch the minus sign in that equation to a plus to account 
	//   for the fact that the map's y-axis actually points downwards.)
	//   http://planning.cs.uiuc.edu/node99.html


    // transfrome observations from veh coordinates into map coordinates
    //for (Particle particle : particles) {
    for (int i = 0; i < particles.size(); i++) {
        std::vector<LandmarkObs> observations_transf;
        particles[i].weight = 1;
        for (LandmarkObs obsrv : observations) {
            LandmarkObs obs_t;
            obs_t.id = obsrv.id;
            //obs_t.x = obsrv.x * cos(particle.theta) + obsrv.y * sin(particle.theta) + particle.x;
            //obs_t.y = -(-1 * obsrv.x * sin(particle.theta) + obsrv.y * cos(particle.theta)) + particle.y;
            obs_t.x = obsrv.x * cos(particles[i].theta) - obsrv.y * sin(particles[i].theta) + particles[i].x;
            obs_t.y = obsrv.x * sin(particles[i].theta) + obsrv.y * cos(particles[i].theta) + particles[i].y;
            observations_transf.push_back(obs_t);

            // calculate distance to each landmark
            vector <double> dists;
            for (Map::single_landmark_s landm : map_landmarks.landmark_list) {
                double dst = dist(landm.x_f, landm.y_f, obs_t.x, obs_t.y);
                dists.push_back(dst);
            }

            // finding the id of the landmark with min distance
            vector<double>::iterator result = min_element(begin(dists), end(dists));
            Map::single_landmark_s lm = map_landmarks.landmark_list[distance(begin(dists), result)];
            obs_t.id = lm.id_i;

            // calculating probability for particle, observation and detected landmark
            double one_over_pi_sigmas = 1./(2*M_PI*std_landmark[0]*std_landmark[1]);
            double expon = -1 * (pow((obs_t.x - lm.x_f),2)/(2*pow(std_landmark[0],2)) + pow((obs_t.y-lm.y_f),2)/(2*pow(std_landmark[1],2)));

            particles[i].weight *= one_over_pi_sigmas * exp(expon);
        }
    }
}

void ParticleFilter::resample() {
	// TODO: Resample particles with replacement with probability proportional to their weight.

	// NOTE: You may find std::discrete_distribution helpful here.
	//   http://en.cppreference.com/w/cpp/numeric/random/discrete_distribution

    std::vector<Particle> particles_new;

    for (int i = 0; i < particles.size(); i++) {
        weights[i] = particles[i].weight;
    }


    std::random_device rd;
    std::mt19937 gen(rd());
    std::discrete_distribution<> d(weights.begin(), weights.end());
    std::map<int, int> m;
    for(int n=0; n<num_particles; ++n) {
        Particle particle_res = particles[d(gen)];
        particles_new.push_back(particle_res);
    }

    particles = particles_new;
}

void ParticleFilter::write(std::string filename) {
	// You don't need to modify this file.
	std::ofstream dataFile;
	dataFile.open(filename, std::ios::app);
	for (int i = 0; i < num_particles; ++i) {
		dataFile << particles[i].x << " " << particles[i].y << " " << particles[i].theta << "\n";
	}
	dataFile.close();
}
